namespace Lista_Filmów
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
                OdczytZPliku();   
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tytul = textBox1.Text;
            string rezyser = textBox2.Text;
            string data = dateTimePicker1.Text;
            string aktor = textBox3.Text;
            if (tytul.Length != 0 && rezyser.Length != 0 && data.Length != 0 && aktor.Length != 0)
            {
                DodawanieDanych(tytul, rezyser, data, aktor);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                dateTimePicker1.Text = "";
            }
            else
            {
                string message = "WPROWADŹ WSZYSTKIE DANE";
                MessageBox.Show(message);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string[] linie = WierszeDoPliku();

            File.WriteAllLines("filmy.txt", linie);
        }


        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void DodawanieDanych(string tytul, string rezyser, string data, string aktor)
        {
            ListViewItem item = new ListViewItem(new string[] { tytul, rezyser, data, aktor });
            listView1.Items.Add(item);
        }

        private void usuńWybraneToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            UsuwanieDanych();
        }

        private void UsuwanieDanych()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                listView1.Items.Remove(item);
            }
            listView1.Refresh();
        }

        private string[] WierszeDoPliku()
        {
            string[] linie = new string[listView1.Items.Count];
            int i = 0;

            foreach (ListViewItem item in listView1.Items)
            {
                linie[i] = "";
                for (int k = 0; k < item.SubItems.Count; k++)
                    linie[i] += item.SubItems[k].Text + "*";

                i++;
            }
            return linie;
        }


        private void OdczytZPliku()
        {
            if (!File.Exists("filmy.txt"))
                return;

            string[] linie = File.ReadAllLines("filmy.txt");
            foreach (string linia in linie)
            {
                string[] temp = linia.Split('*');
                DodawanieDanych(temp[0], temp[1], temp[2], temp[3]);
            }
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ZamianaDanych();
        }

        private void zamia(string tytul, string rezyser, string data, string aktor)
        {
            ListViewItem ZamianaDanych = new ListViewItem(new string[] { tytul, rezyser, data, aktor });
            listView1.Items.Add(ZamianaDanych);
        }
        private void ZamianaDanych()
        {
            string tytul = textBox1.Text;
            string rezyser = textBox2.Text;
            string data = dateTimePicker1.Text;
            string aktor = textBox3.Text;

            foreach (ListViewItem item in listView1.SelectedItems)
            {
                string[] linie = { tytul, rezyser, data, aktor };
                listView1.Items.Remove(item);
                listView1.Items.Add(Convert.ToString(linie));


            }
            listView1.Refresh();
        }






    }
}